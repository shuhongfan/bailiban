var game = {
    score: 0,
    data:[],
    gamerunning:1,   //游戏运行中的状态
    gameover: 0,  //游戏结束的状态
    status: 0,   //游戏的状态，这个状态要时刻跟上面两个状态进行比较，并且判断游戏目前处于什么状态
    start :function(){
        this.score = 0;
        this.status = this.gamerunning;
        this.data = [];
        for(var r=0;r<4;r++){
            this.data[r] = [];//创建四行
            for(var c=0;c<4;c++){
                this.data[r][c] = 0;
            }
        }
        this.randomNum();
        this.randomNum();
        this.dataView();
    },
    randomNum:function(){
        //生成随机数的函数，随机生成2或者4，2比4概率高很多
        //1.生成随机数不能占数组中有数字的地方，生成随机数只能在数组为0的位置进行生成
        //2.找数组中存在0的位置
        //通过孙环不停的找0的位置，当找到数组中有0的位置，放置2或者4，结束循环
       for(;;){
            var r = Math.floor(Math.random()*4);
            var c = Math.floor(Math.random()*4);
            if(this.data[r][c] == 0){
                // 生成2或者4 的随机数
                var num = Math.random() > 0.3 ? 2 : 4;
                this.data[r][c] = num;
                break;
            }
        }
    },
    dataView:function(){//数据更新
        for(var r = 0;r<4;r++){
            for(var c = 0;c<4;c++){
                var div = document.getElementById("c" + r + c);
                // console.log(div)
                if(this.data[r][c]!=0){
                    div.innerHTML = this.data[r][c];
                    div.className = 'cell n' +this.data[r][c];
                }else{
                    div.innerHTML = '';
                    div.className = "cell";
                }
            }
        }
        //设置分数
        document.getElementById("score01").innerHTML = this.score;
        // 试图更新，关心游戏是否结束
        //直接根据
        if(this.status == this.gameover){
            document.getElementById("score02").innerHTML=this.score;
            document.getElementById("gameover").style.display='block';
        }
            else{
            document.getElementById("gameover").style.display = 'none';
        }
    },
    isgameover : function(){//判断游戏是否结束的方法
        // 1.数组中还有0；
        // 2.数组中已经占满，但是左右有相邻
        // 3.数组中已经占满，但是上下有相同
        for(var r = 0;r<4;r++){
            for(var c= 0;c<4;c++){
                if(this.data[r][c] == 0){
                    return false;
                }
                if( c < 3 ){
                    if(this.data[r][c] == this.data[r][c+1]){
                        return false;
                    }
                }
                if(r<3){
                    if(this.data[r][c] == this.data[r+1][c]){
                        return false;
                    }
                }
            }
        }
        return true; //上面三个条件都不满足，判断游戏结束
    },
    //左移动
    moveLeft: function(){
        var before = this.data.toString();
        // console.log(this.data)
        //移动部分逻辑
        //4行，封装一个函数，循环执行四次即可
        for(var r=0;r<4;r++){
            this.moveLeftInRow(r);//函数只需要管一行
        }
        var after = this.data.toString();
        //移动之前   数组记录一次
        //移动的逻辑部分
        //移动之后  数组记录一次
        //当移动之前的数组不等于移动之后的数组，移动了
        //1.生成一个随机数
        //2.生成玩了一个随机数，游戏可能会结束。调用判断游戏是否结束的方法
        //3.更新视图，调用更新视图的函数
        if(before != after){
            this.randomNum();
            if(this.isgameover()){
                this.status = this.gameover;
            }
            this.dataView();
        }
    },
    moveLeftInRow :function(r){//处理每一行的逻辑的函数
        // 找后面不为0的位置
        for(c=0;c<3;c++){
           var nextc = this.getNextInRow(r,c);
           if(nextc != -1){
               if(this.data[r][c] == 0){
                   this.data[r][c] = this.data[r][nextc];
                   this.data[r][nextc] = 0;
                   c--;
               }else if(this.data[r][c] == this.data[r][nextc]){
                   this.data[r][c]*=2;
                   this.data[r][nextc]=0;
                   this.score +=this.data[r][c];
               }
           }else {
               break;
           }
        }
    },
    getNextInRow:function(r,c){
        for(var i = c+1;i<4;i++){
            // 找到就返回具体的位置
            if(this.data[r][i]!=0){
                return i;
            }
        }
        return -1;//没找到就返回一个标识符
    },

    //右移动
    moveRight: function(){
        var before = this.data.toString();
       
        for(var r=0;r<4;r++){
            this.moveRightInRow(r);//函数只需要管一行
        }
        var after = this.data.toString();
        if(before !=after){
            this.randomNum();
            if(this.isgameover()){
                this.status = this.gameover;
            }
            this.dataView();
        }
    },
    moveRightInRow:function(r){//处理每一行的逻辑的函数
        // 找后面不为0的位置
        for(c=3;c>0;c--){
           var nextc = this.RightgetNextInRow(r,c);
           if(nextc != -1){
               if(this.data[r][c] == 0){
                   this.data[r][c] = this.data[r][nextc];
                   this.data[r][nextc] = 0;
                   c++;
               }else if(this.data[r][c] == this.data[r][nextc]){
                   this.data[r][c]*=2;
                   this.data[r][nextc]=0;
                   this.score +=this.data[r][c];
               }
           }else {
               break;
           }
        }
    },
    RightgetNextInRow:function(r,c){
        for(var i = c-1;i>=0;i--){
            // 找到就返回具体的位置
            if(this.data[r][i]!=0){
                return i;
            }
        }
        return -1;//没找到就返回一个标识符
    },
//上移动
moveTop: function(){
    var before = this.data.toString();
   
    for(var r=0;r<4;r++){
        this.moveTopInRow(r);//函数只需要管一行
    }
    var after = this.data.toString();
    if(before !=after){
        this.randomNum();
        if(this.isgameover()){
            this.status = this.gameover;
        }
        this.dataView();
    }
},
moveTopInRow:function(r){//处理每一行的逻辑的函数
    // 找后面不为0的位置
    for(c=0;c<3;c++){
       var nextc = this.TopgetNextInRow(r,c);
       if(nextc != -1){
           if(this.data[c][r] == 0){
               this.data[c][r] = this.data[nextc][r];
               this.data[nextc][r] = 0;
               c++;
           }else if(this.data[c][r] == this.data[nextc][r]){
               this.data[c][r]*=2;
               this.data[nextc][r]=0;
               this.score +=this.data[c][r];
           }
       }else {
           break;
       }
    }
},
TopgetNextInRow:function(r,c){
    for(var i = c+1;i<4;i++){
        // 找到就返回具体的位置
        if(this.data[i][r]!=0){
            return i;
        }
    }
    return -1;//没找到就返回一个标识符
},
//右移动
moveBottom: function(){
    var before = this.data.toString();
   
    for(var r=0;r<4;r++){
        this.moveBottomInRow(r);//函数只需要管一行
    }
    var after = this.data.toString();
    if(before !=after){
        this.randomNum();
        if(this.isgameover()){
            this.status = this.gameover;
        }
        this.dataView();
    }
},
moveBottomInRow:function(r){//处理每一行的逻辑的函数
    // 找后面不为0的位置
    for(c=3;c>0;c--){
       var nextc = this.BottomgetNextInRow(r,c);
       if(nextc != -1){
           if(this.data[c][r] == 0){
               this.data[c][r] = this.data[nextc][r];
               this.data[nextc][r] = 0;
               c++;
           }else if(this.data[c][r] == this.data[nextc][r]){
               this.data[c][r]*=2;
               this.data[nextc][r]=0;
               this.score +=this.data[c][r];
           }
       }else {
           break;
       }
    }
},
BottomgetNextInRow:function(r,c){
    for(var i = c-1;i>=0;i--){
        // 找到就返回具体的位置
        if(this.data[i][r]!=0){
            return i;
        }
    }
    return -1;//没找到就返回一个标识符
},
}
game.start();
//
document.onkeydown = function(e){
    console.log(e.keyCode)
if(e.keyCode == 37){
    game.moveLeft();
}
else if (e.keyCode == 38) {
    game.moveTop();
}
else if (e.keyCode == 39) {
    game.moveRight();	
}
else if (e.keyCode == 40) {
    game.moveBottom();
}	
}


// console.log(game.data);