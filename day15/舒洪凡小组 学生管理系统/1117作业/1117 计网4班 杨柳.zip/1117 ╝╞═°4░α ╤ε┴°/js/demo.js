var game = {
    score: 0,
    data: [],
    gameruning: 1,
    gamemover: 0,
    state: 1,
    r: 4,
    c: 4,
    start: function () {
        this.score = 0;
        this.state = 1;
        for (let i = 0; i < this.r; i++) {
            this.data[i] = []
            for (let j = 0; j < this.c; j++) {
                this.data[i][j] = 0;
            }
        }
        this.randomss();
        this.randomss();
        this.updateview();
    },
    randomss: function () {
        for (; ;) {
            let r = Math.floor(Math.random() * 4);
            let c = Math.floor(Math.random() * 4);
            if (this.data[r][c] == 0) {
                let rad = Math.random() > 0.3 ? 2 : 4;
                this.data[r][c] = rad;
                break;
            }
        }
    },
    updateview: function () {
        for (let i = 0; i < this.r; i++) {
            for (let j = 0; j < this.c; j++) {
                var div = document.getElementById('n' + i + j);
                // console.log(i+' '+j);
                div.innerHTML = this.data[i][j];
                if (this.data[i][j] != 0) {
                    div.className = "cell n" + this.data[i][j];
                } else {
                    div.className = "cell";
                    div.innerHTML = "";
                }
            }
        }
        document.getElementById("score01").innerHTML = this.score;
        document.getElementById("score02").innerHTML = this.score;
    },
    gamestate: function () {
        for (let i = 0; i < this.r; i++) {
            for (let j = 0; j < this.c; j++) {
                if (this.data[i][j] == 0) {
                    return false;
                }
                if (this.data[i][j] == this.data[i][j + 1]) {
                    return false;
                }
                if (this.data[i][j] == this.data[i + 1][j]) {
                    return false;
                }
            }
        }
        return true;
    },
    leftmoves: function (r) {
        for (let c = 0; c < this.c; c++) {
            this.getleftmoves(r, c)

        }
    },
    getleftmoves: function (r, c) {
        for (let i = c + 1; i < this.c; i++) {
            if (this.data[r][i] != 0) {
                if (this.data[r][c] == 0) {
                    this.data[r][c] = this.data[r][i];
                    this.data[r][i] = 0;
                    i--;
                    return this.data[r][c];
                } else if (this.data[r][c] == this.data[r][i]) {
                    if (i != c + 1) continue;
                    this.data[r][c] *= 2;
                    this.data[r][i] = 0;
                    this.score += this.data[r][c];
                    return this.data[r][c];
                }
            }
        }
        return -1;
    },
    left: function () {
        // 移动判断
        let beforearr = this.data.toString();
        for (let r = 0; r < this.r; r++) {
            this.leftmoves(r)
        }
        this.isgameover() //判断游戏结束
        // if (this.data.toString() != beforearr) {
            this.randomss();
            this.updateview();
        // }
    },
    right: function () {
        console.log('right');
    },
    top: function () {
        console.log('top');
    },
    bottom: function () {
        console.log('bottom');
    },
    isgameover: function () {
        if (this.gamestate()) {
            this.state = this.gamemover;
            document.getElementById('reload').style.display = 'block';
            console.log('game over');
        } else {
            this.state = this.gameruning;
            document.getElementById('reload').style.display = 'none';
        }
    }
};
game.start();
console.log(game.data);
document.onkeydown = function (event) {
    let e = event || window.event;
    let kcode = e.keyCode;
    switch (kcode) {
        case 37: game.left(); break;  //左
        case 39: game.right(); break;  //右
        case 38: game.top(); break;  //上
        case 40: game.bottom(); break;  //下
    }
}