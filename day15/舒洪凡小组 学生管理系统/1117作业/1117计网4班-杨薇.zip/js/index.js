var game = {
    score: 0,
    data: [],
    gamerunning: 1,
    gameover: 0,
    status: 1,
    arrCurIndex: [],
    start: function () {
        this.score = 0
        this.status = this.gamerunning
        this.data = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
        ]

        this.randomNum()
        this.randomNum()
        this.dataView()


        this.move()

    },
    randomNum: function () { //   生成随机数的函数，随机生成2或者4，2比4的概率高很多
        // 生成的随机数不能占数组中有数字的地方，生成随机数只能再数组为0的位置进行生成
        // 找数组中存在0的位置
        // 通过循环不停的找0的位置，当找到数组有0的位置，开始放置2或者4，结束循环
        while (true) {
            var r = Math.floor(Math.random() * 4)
            var c = Math.floor(Math.random() * 4)
            if (this.data[r][c] == 0) {
                // 生成2或者4的随机数
                var num = Math.random() > 0.2 ? 2 : 4
                this.data[r][c] = num

                break
            }
        }
    },
    dataView: function () { // 数据更新
        var score = 0
        for (var r = 0; r < 4; r++) {
            for (var c = 0; c < 4; c++) {
                if (this.data[r][c] != 0) {
                    document.getElementById("c" + r + c).innerHTML = this.data[r][c]
                    document.getElementById("c" + r + c).className = "cell n" + this.data[r][c]

                    score += this.data[r][c]


                } else {
                    document.getElementById("c" + r + c).innerText = ''
                    document.getElementById("c" + r + c).className = 'cell'
                }
            }
        }
        this.score = score
        document.getElementById('score01').innerText = this.score
        if (this.status == this.gameover) {
            document.getElementById('score02').innerHTML = this.score
            document.getElementById('gameover').style.display = 'block'
        } else {
            document.getElementById('gameover').style.display = "none"
        }
    },
    isgameover: function () {
        for (var r = 0; r < 4; r++) {
            for (var c = 0; c < 4; c++) {
                if (this.data[r][c] == 0) {
                    return false
                }
                if (c < 3) {
                    if (this.data[r][c] == this.data[r][c + 1]) {
                        return false
                    }
                }
                if (r < 3) {
                    if (this.data[r][c] == this.data[r + 1][c]) {
                        return false
                    }
                }
            }
        }
        return true
    },
    move: function () {

        document.onkeydown = (e) => {
            switch (e.keyCode) {
                case 37:
                    this.left()
                    break
                case 38:
                    this.top()
                    break
                case 39:
                    this.right()
                    break
                case 40:
                    this.bottom()
                    break
            }
        }
    },
    left: function () {
        // 移动之前 数组记录一次
        var before = this.data.toString()

        // 移动的逻辑部分,循环执行4次即可
        for (var r = 0; r < 4; r++) {
            this.moveLeftInRow(r)
        }
        var after = this.data.toString()

        // 当移动之前的数组不等于移动之后的数组，移动了
        // 1、生成一个随机数，调用生成随机数的函数
        // 2、生成完了一个随机数，游戏可能会结束，调用判断游戏结束的方法
        // 3、更新视图，调用更新视图的函数
        if (before != after) {

            this.randomNum()
            if (this.isgameover()) {
                this.status = this.gameover
            }
            this.dataView()
        }

    },
    bottom: function () {

    },
    moveLeftInRow: function (r) { // 处理每一行的逻辑函数
        // 找后面不为0的位置
        for (var c = 0; c < 3; c++) { // 最有边不要考虑
            var nextc = this.getNextInRow(r, c)
            if (nextc != -1) { // 表示当前位置的后面有数字
                if (this.data[r][c] == 0) { // 自己的位置为0
                    this.data[r][c] = this.data[r][nextc]
                    this.data[r][nextc] = 0
                    c--
                } else if (this.data[r][c] == this.data[r][nextc]) {
                    this.data[r][c] *= 2
                    this.data[r][nextc] = 0
                    this.score += this.data[r][c]

                }
            } else {
                break
            }
        }
    },

    getNextInRow: function (r, c) {
        for (var i = c + 1; i < 4; i++) {
            // 找到就返回具体的位置
            if (this.data[r][i] != 0) {
                return i
            }
        }
        return -1 // 没找到就返回一个标识符
    },
    // 上移动
    top: function () {

        // 移动之前 数组记录一次
        var before = this.data.toString()

        // 移动的逻辑部分,循环执行4次即可
        for (var c = 0; c < 4; c++) {
            this.moveTopInCol(c)
        }


        // 移动之后 数组记录一次
        var after = this.data.toString()


        // 当移动之前的数组不等于移动之后的数组，移动了
        // 1、生成一个随机数，调用生成随机数的函数
        // 2、生成完了一个随机数，游戏可能会结束，调用判断游戏结束的方法
        // 3、更新视图，调用更新视图的函数
        if (before != after) {
            this.randomNum()
            if (this.isgameover()) {
                alert('hhe')
                this.status = this.gameover
            }
            this.dataView()
        }
    },
    moveTopInCol: function (c) { // 处理每一列的逻辑代码

        // 找下面不为0的位置
        for (var r = 0; r < 3; r++) { // 00 10 20     01 11 21    02 12 22    03 13 23

            var nextc = this.getNextInCol(c, r)


            if (nextc != -1) { // 表示当前位置的后面有数字
                if (this.data[r][c] == 0) { // 自己的位置为0
                    this.data[r][c] = this.data[nextc][c]
                    this.data[nextc][c] = 0
                    r--
                } else if (this.data[r][c] == this.data[nextc][c]) {
                    this.data[r][c] *= 2
                    this.data[nextc][c] = 0
                    this.score += this.data[r][c]
                }
            } else {
                break
            }
        }

    },
    getNextInCol: function (c, r) {
        for (var i = r + 1; i < 4; i++) {
            // 找到就返回具体的位置
            if (this.data[i][c] != 0) {
                return i
            }
        }
        return -1
    },
    // 右移动
    right: function () {
        // 移动之前 数组记录一次
        var before = this.data.toString()

        // 移动的逻辑部分,循环执行4次即可
        for (var r = 0; r < 4; r++) {
            this.moveRightInCol(r)
        }


        // 移动之后 数组记录一次
        var after = this.data.toString()


        // 当移动之前的数组不等于移动之后的数组，移动了
        // 1、生成一个随机数，调用生成随机数的函数
        // 2、生成完了一个随机数，游戏可能会结束，调用判断游戏结束的方法
        // 3、更新视图，调用更新视图的函数
        if (before != after) {
            this.randomNum()
            if (this.isgameover()) {
                this.status = this.gameover
            }
            this.dataView()
        }
    },
    moveRightInCol: function (r) { // 处理每一列的逻辑代码

        // 找后面不为0的位置
        for (var c = 3; c > 0; c--) { // 最有边不要考虑
            var nextc = this.getPrevInRow(r, c)
            if (nextc != -1) { // 表示当前位置的后面有数字
                if (this.data[r][c] == 0) { // 自己的位置为0
                    this.data[r][c] = this.data[r][nextc]
                    this.data[r][nextc] = 0
                    c++
                } else if (this.data[r][c] == this.data[r][nextc]) {
                    this.data[r][c] *= 2
                    this.data[r][nextc] = 0
                    this.score += this.data[r][c]
                }
            } else {
                break
            }
        }

    },
    getPrevInRow: function (r, c) {
        for (var i = c - 1; i >= 0; i--) {
            // 找到就返回具体的位置
            if (this.data[r][i] != 0) {
                return i
            }
        }
        return -1 // 没找到就返回一个标识符
    },
    // 下移动
    bottom: function () {

        var before = this.data.toString()

        // 移动的逻辑部分,循环执行4次即可
        for (var c = 0; c < 4; c++) {
            this.moveBottomInCol(c)
        }

        // 移动之后 数组记录一次
        var after = this.data.toString()


        // 当移动之前的数组不等于移动之后的数组，移动了
        // 1、生成一个随机数，调用生成随机数的函数
        // 2、生成完了一个随机数，游戏可能会结束，调用判断游戏结束的方法
        // 3、更新视图，调用更新视图的函数
        if (before != after) {
            this.randomNum()
            if (this.isgameover()) {
                this.status = this.gameover
            }
            this.dataView()
        }
    },
    moveBottomInCol: function (c) { // 处理每一列的逻辑代码

        // 找下面不为0的位置
        for (var r = 3; r > 0; r--) { // 00 10 20     01 11 21    02 12 22    03 13 23

            var nextc = this.getPrevInCol(c, r)


            if (nextc != -1) { // 表示当前位置的后面有数字
                if (this.data[r][c] == 0) { // 自己的位置为0
                    this.data[r][c] = this.data[nextc][c]
                    this.data[nextc][c] = 0
                    r++
                } else if (this.data[r][c] == this.data[nextc][c]) {
                    this.data[r][c] *= 2
                    this.data[nextc][c] = 0
                    this.score += this.data[r][c]
                }
            } else {
                break
            }
        }

    },
    getPrevInCol: function (c, r) {
        for (var i = r - 1; i >= 0; i--) {
            // 找到就返回具体的位置
            if (this.data[i][c] != 0) {
                return i
            }
        }
        return -1
    },
}

game.start()